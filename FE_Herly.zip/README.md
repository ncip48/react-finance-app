# Pre requirement

1. Node JS v16
2. NPM v8.19
3. React v18.20

# Installation

1. Type `npm install` in command prompt / terminal
2. Type `npm start` in command prompt / terminal
3. Open `localhost:3000` in web browser
4. Or open this url to show the demo `https://finance-4658.netlify.app`
